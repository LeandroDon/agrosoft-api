import { Router } from 'express';
export const plotRouter = Router();

// TODO: reemplazar con tu lógica real
plotRouter.get('/', (_req, res) => res.json([{ id: 1, name: 'Lote A' }]));
