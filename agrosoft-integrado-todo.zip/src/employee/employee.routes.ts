import { Router } from 'express';
export const employeeRouter = Router();

// TODO: reemplazar con tu lógica real
employeeRouter.get('/', (_req, res) => res.json([{ id: 1, name: 'Empleado demo' }]));
