import express from 'express';
import { plotRouter } from './src/plot/plot.routes';
import machineryRoutes from './src/machinery/machinery.routes';
import { employeeRouter } from './src/employee/employee.routes';

const app = express();

app.use(express.json())

app.use('/api/plots', plotRouter);
app.use('/api/machinery', machineryRoutes);
app.use('/api/employees', employeeRouter);

app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error(err);
  res.status(err?.status ?? 500).json({ message: err?.message ?? 'Internal Server Error' });
});

app.listen(3000, () => {
  console.log('Server runnning on http://localhost:3000/')
})
